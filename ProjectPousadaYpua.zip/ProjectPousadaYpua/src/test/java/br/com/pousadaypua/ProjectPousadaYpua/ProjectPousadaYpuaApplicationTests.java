package br.com.pousadaypua.ProjectPousadaYpua;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectPousadaYpuaApplicationTests {

	@Test
	void contextLoads() {
	}

}
