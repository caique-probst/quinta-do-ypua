package br.com.pousadaypua.ProjectPousadaYpua;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectPousadaYpuaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectPousadaYpuaApplication.class, args);
	}

}
